<?php
include(__DIR__.'/controller.php');
SessionManager::startSession();
SessionManager::logout();
header('Location: ./login.php');
?>