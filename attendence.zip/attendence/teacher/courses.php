<?php
include('header.php');
?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <button type="button" class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#myModal">+ Course</button>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb"><a href="">Home / </a></li>
                                <li class="breadcrumb-item active">Courses</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>N <sup>0</sup></th>
                                        <th>Course Name</th>
                                        <th>Course Code</th>
                                        <th>Credit</th>
                                        <th>Created date</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>


                                <tbody>
                                    <?php
                                    $courses = Attendance::AllCourses();
                                    foreach ($courses as $key => $Course) {
                                    ?>
                                    <tr>
                                    <td><?= $key + 1 ?></td>
                                            <td><?= $Course['course_name'] ?></td>
                                            <td><?= $Course['course_code'] ?></td>
                                            <td><?= $Course['credit'] ?></td>
                                            <td><?= $Course['created_date'] ?></td>
                                        
                                        <td>
                                            <a href="edit-Course.php?c_id=<?= $Course['course_id'] ?>" class="btn btn-primary">Edit</a>
                                            <a href="server/save-Course.php?delete_Course=<?= $Course['course_id'] ?>" class="btn btn-danger">Delete</a>

                                        </td>
                                        
                                    </tr>

                                    <?php
                                    }?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <div class="card">
        <div class="card-body">
            <div>
                <!-- sample modal content -->
                <div id="myModal" class="modal fade" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="myModalLabel">Record new student</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <form method="post" action="server/save-Course.php">
                                    <input type="hidden" name="new_courses">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Course name</label>
                                                <input type="text" class="form-control" name="course_name" id="formrow-email-input" placeholder="Enter Course name">
                                            </div>
                                        </div>
                                        
                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Course Code</label>
                                                <input type="text" name="course_code" class="form-control" id="formrow-email-input" placeholder="Course code">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-telephone-input" class="form-label">Credits</label>
                                                <input type="number" name="credit" class="form-control" id="formrow-telephone-input" placeholder="Enter credit of lesson">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                            </div>
                                </form>

                            </div>
                            
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </div> <!-- end preview-->

        </div>
        <!-- end card body -->
    </div>
    <?php
    include('footer.php');
    ?>