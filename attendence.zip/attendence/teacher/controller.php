<?php

include(__DIR__.'/../resources/AllConfig.php');

class Attendance{
    static function getAllStudents(){
        $students = Pasco::read('students','*')
        ->execute();
        return $students;
    }

    static function getStudent($id){
        $student = Pasco::read('students','*', "student_id = $id")->execute();
        return $student;
    }

    static function AllCourses(){
        $courses = Pasco::read('courses','*')
        ->execute();
        return $courses;
    }

    static function getCourse($id){
        $course = Pasco::read('courses','*', "course_id = $id")->execute();
        return $course;
    }

    static function stBy($sid,$date){
        $course = Pasco::read('attendances','*', "student_id = '$sid' and attendance_date = '$date'")->execute();
        if($course != false){
            return $course[0];
        }else{
            return false;
        }
    }

    // get getGrades

    static function getGrades($id){
        $grades = Pasco::read('grades','*', "student_id = $id")->execute();
        return $grades;
    }

    // all getAllCourses

    static function getAllCourses(){
        $courses = Pasco::read('courses','*')->execute();
        return $courses;
    }
}
?>