<?php
include('header.php');
?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <button type="button" class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#myModal">+ Students</button>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb"><a href="">Home / </a></li>
                                <li class="breadcrumb-item active">Students</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>N <sup>0</sup></th>
                                        <th>Firstname</th>
                                        <th>Lastname</th>
                                        <th>Email</th>
                                         <th>Gender</th>
                                        <th>telephone</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $students = Attendance::getAllStudents();
                                    foreach ($students as $key => $student) {
                                    ?>
                                    <tr>
                                    <td><?= $key + 1 ?></td>
                                            <td><?= $student['firstname'] ?></td>
                                            <td><?= $student['lastname'] ?></td>
                                            <td><?= $student['email'] ?></td>
                                            <td><?= $student['gender'] ?></td>
                                            <td><?= $student['telephone'] ?></td>
                                            

                                        <td>
                                            <a href="edit-students.php?s_id=<?= $student['student_id'] ?>" class="btn btn-primary">Edit</a>
                                            <a href="server/save-students.php?delete_student=<?= $student['student_id'] ?>" class="btn btn-danger">Delete</a>

                                        </td>
                                        
                                    </tr>

                                    <?php
                                    }?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <div class="card">
        <div class="card-body">
            <div>
                <!-- sample modal content -->
                <div id="myModal" class="modal fade" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="myModalLabel">Record new student</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <form method="post" action="server/save-students.php">
                                    <input type="hidden" name="new_students">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Firstname</label>
                                                <input type="text" class="form-control" name="firstname" id="formrow-email-input" placeholder="Enter Your Firstname">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-lastname-input" class="form-label">Lastname</label>
                                                <input type="text" name="lastname" class="form-control" id="formrow-lastname-input" placeholder="Enter Your Lastname">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Email</label>
                                                <input type="email" name="email" class="form-control" id="formrow-email-input" placeholder="Enter Your Email ID">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="formrow-telephone-input" class="form-label">Telephone</label>
                                                <input type="text" name="telephone" class="form-control" id="formrow-telephone-input" placeholder="Enter Your telephone">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="formrow-firstname-input" class="form-label">Gender </label>
                                        <select name="gender" id="" class="form-control">
                                            <option value="">Select Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>


                                    <div class="modal-footer">
                                <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                            </div>
                                </form>

                            </div>
                            
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </div> <!-- end preview-->

        </div>
        <!-- end card body -->
    </div>
    <?php
    include('footer.php');
    ?>