<?php
include(__DIR__.'/controller.php');
if($_GET['st'] == 'all'){
    $all = Attendance::getAllStudents();
    echo json_encode($all);
}

if($_GET['st'] == 'one'){
    $id = $_GET['id'];
    $one = Attendance::getStudent($id);
    echo json_encode($one);
}

?>