<?php
include('../resources/AllConfig.php');

$select = Pasco::read('users')
->execute();

if($select)
{
    echo json_encode($select);
}
?>