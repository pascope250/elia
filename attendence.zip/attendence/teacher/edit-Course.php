<?php
include('header.php');
?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <a href="courses.php">
                            <button type="button" class="btn btn-primary"><- Back</button>
                        </a>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb"><a href="">Home / </a></li>
                                <li class="breadcrumb-item active">Course</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="modal-body">
                            <div class="card-header">
                                <h4 class="card-title text-center
                                ">Edit Course</h4>
                            </div>

                            <?php
                            $course = Attendance::getCourse(P_Method::input('c_id'));
                            ?>
                            <form method="post" action="server/save-Course.php">
                                <input type="hidden" name="new_courses" value="<?= $course[0]['course_id'] ?>">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">Course name</label>
                                            <input type="text" class="form-control" value="<?= $course[0]['course_name'] ?>" name="course_name" id="formrow-email-input" placeholder="Enter Course name">
                                        </div>
                                    </div>

                                </div>

                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-email-input" class="form-label">Course Code</label>
                                            <input type="text" name="course_code" value="<?= $course[0]['course_code'] ?>" class="form-control" id="formrow-email-input" placeholder="Course code">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="formrow-telephone-input" class="form-label">Credits</label>
                                            <input type="number" name="credit" class="form-control" value="<?= $course[0]['credit'] ?>" id="formrow-telephone-input" placeholder="Enter credit of lesson">
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <?php
    include('footer.php');
    ?>