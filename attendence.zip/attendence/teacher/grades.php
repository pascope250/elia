<?php
include('header.php');
?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">GRADES</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb"><a href="javascript: void(0);">Grades/ </a></li>
                                <li class="breadcrumb-item active">Grades</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">

                                <?php

                                $alls = Attendance::getAllStudents();

                                ?>
                                <thead>
                                    <tr>
                                        <th>Firstname</th>
                                        <th>Lastname</th>
                                        <th>Course Name</th>
                                        <th>Grade</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>


                                <tbody>
                                    <?php
                                    foreach ($alls as $key => $all) {
                                    ?>
                                        <tr>
                                            <td><?= $all['firstname'] ?></td>
                                            <td><?= $all['lastname'] ?></td>
                                            <?php
                                            $getgrades = Attendance::getGrades($all['student_id']);
                                            ?>
                                            <?php if ($getgrades) {
                                                $getcourses = Attendance::getCourse($getgrades[0]['course_id']);
                                            } ?>
                                            <td>
                                                <?= (isset($getcourses)) ? ($getcourses[0]['course_name']) : 'No Course' ?>
                                            </td>


                                            <td>
                                                <?= ($getgrades) ? ($getgrades[0]['grades']) : 'No Grade' ?>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#myModal" id="getStid" data-id="<?= $all['student_id'] ?>">+ Grades</button>
                                                <!-- delete grade -->
                                                <?php if ($getgrades) {?>
                                                <a href="server/save-grades.php?delete_grade=<?= $getgrades[0]['grade_id'] ?>" class="btn btn-danger">Delete</a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->



    <div class="card">
        <div class="card-body">
            <div>
                <!-- sample modal content -->
                <div id="myModal" class="modal fade" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="myModalLabel">Add Grades</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <form method="post" action="server/save-grades.php">
                                    <input type="hidden" name="stid" id="stid">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Course Name</label>
                                                <?php
                                                $course = Attendance::getAllCourses();
                                                ?>

                                                <select class="form-select" name="course_id" required>
                                                    <option value="">Select Course</option>
                                                    <?php
                                                    foreach ($course as $key => $courses) {
                                                    ?>
                                                        <option value="<?= $courses['course_id'] ?>"><?= $courses['course_name'] ?></option>
                                                    <?php
                                                    }
                                                    ?>

                                                </select>

                                            </div>
                                        </div>

                                    </div>



                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label for="formrow-email-input" class="form-label">Grades</label>
                                                <?php
                                                $grades = ['DBD', 'DB+', 'DB', 'DST+', 'DST', 'NDST'];
                                                ?>

                                                <select class="form-select" name="grades" required>
                                                    <option value="">Select Grade</option>
                                                    <?php
                                                    foreach ($grades as $key => $grade) {
                                                    ?>
                                                        <option value="<?= $grade ?>"><?= $grade ?></option>
                                                    <?php
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                                    </div>
                                </form>

                            </div>

                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </div> <!-- end preview-->

        </div>
        <!-- end card body -->
    </div>
    <?php
    include('footer.php');
    ?>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#getStid', function() {
                var id = $(this).data('id');
                $('#stid').val(id);
            });
        });
    </script>