<?php
include(__DIR__.'/../controller.php');
if(P_Method::isPost() && empty(P_Method::input('new_students'))){

    $data =
     [
        'firstname' => P_Method::input('firstname'),
        'lastname' => P_Method::input('lastname'),
        'email' => P_Method::input('email'),
        'telephone' => P_Method::input('telephone'),
        'gender' => P_Method::input('gender'),
     ];
     $save = Pasco::create('students', $data);
     if($save != false)
     {
         echo '<script>alert("Data saved successfully")</script>';
         header('Location: ../students.php');
     }
     else
     {
         echo '<script>alert("Data not saved")</script>';
         header('Location: ../students.php');
     }
}

if(P_Method::isPost() && !empty(P_Method::input('new_students'))){

      $id = P_Method::input('new_students');

      $data =
       [
          'firstname' => P_Method::input('firstname'),
          'lastname' => P_Method::input('lastname'),
          'email' => P_Method::input('email'),
          'telephone' => P_Method::input('telephone'),
          'gender' => P_Method::input('gender')
       ];

         $update = Pasco::update('students', $data, "student_id = $id");

         if($update != false)
         {
             echo '<script>alert("Data updated successfully")</script>';
             header('Location: ../students.php');
         }
         else
         {
             echo '<script>alert("Data not updated")</script>';
             header('Location: ../students.php');
         }
}



if(!empty(P_Method::input('delete_student'))){

    $id = P_Method::input('delete_student');


    $delete = Pasco::delete('students', "student_id = $id");

    if($delete != false)
    {
        echo '<script>alert("Data deleted successfully")</script>';
        header('Location: ../students.php');
    }
    else
    {
        echo '<script>alert("Data not deleted")</script>';
        header('Location: ../students.php');
    }
}


