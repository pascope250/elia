<?php
include(__DIR__.'/../controller.php');

if(P_Method::isPost() && empty(P_Method::input('new_courses'))){

    $data =
     [
        'course_name' => P_Method::input('course_name'),
        'course_code' => P_Method::input('course_code'),
        'credit' => P_Method::input('credit'),
     ];
     $save = Pasco::create('courses', $data);
     if($save != false)
     {
         echo '<script>alert("Data saved successfully")</script>';
         header('Location: ../courses.php');
     }
     else
     {
         echo '<script>alert("Data not saved")</script>';
         header('Location: ../courses.php');
     }
}

if(P_Method::isPost() && !empty(P_Method::input('new_courses'))){

      $id = P_Method::input('new_courses');

      $data =
       [
          'course_name' => P_Method::input('course_name'),
          'course_code' => P_Method::input('course_code'),
          'credit' => P_Method::input('credit')
       ];

          $update = Pasco::update('courses', $data, "course_id = $id");

          if($update != false)
          {
              echo '<script>alert("Data updated successfully")</script>';
              header('Location: ../courses.php');
          }
          else
          {
              echo '<script>alert("Data not updated")</script>';
              header('Location: ../courses.php');
          }
          
}


if(!empty(P_Method::input('delete_Course'))){

    $id = P_Method::input('delete_Course');


    $delete = Pasco::delete('courses', "course_id = $id");

    if($delete != false)
    {
        echo '<script>alert("Data deleted successfully")</script>';
        header('Location: ../courses.php');
    }
    else
    {
        echo '<script>alert("Data not deleted")</script>';
        header('Location: ../courses.php');
    }

}



?>