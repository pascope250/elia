<?php

include(__DIR__.'/../controller.php');

if(P_Method::input('isAttend')|| P_Method::input('isNotAttend')){
$s_id = $_GET['s_id'];

var_dump($s_id);
$attendance_date = P_Method::input('attendance_date');

$data = 
[
    'student_id'=> P_Method::input('s_id'),
    'attendance_date'=> P_Method::input('attendance_date'),
    'status'=>'ATTENDED',
];

if(P_Method::input('isNotAttend')){
    $data['status'] = 'N0TATTENDED';
}

$select = Pasco::read("attendances",'*', "student_id = '$s_id' and attendance_date = '$attendance_date'")->execute();
if($select !=false){
    if($select[0]['status'] === 'ATTENDED'){
        
        $data = ["status" => "N0TATTENDED"];
        $attent = Pasco::update('attendances',$data,"student_id = '$s_id' and attendance_date = '$attendance_date'");
        if($attent){
            $url = 'create-attendance.php?attendance_date='.P_Method::input('attendance_date');
            header('location: ../'.$url);
        }else{
            echo 'there are an error occured please try again later';
        }
    }else{
        $data = ["status" => "ATTENDED"];
        $attent = Pasco::update('attendances',$data,"student_id = '$s_id' and attendance_date = '$attendance_date'");
        if($attent){
            $url = 'create-attendance.php?attendance_date='.P_Method::input('attendance_date');
            header('location: ../'.$url);
        }else{
            echo 'there are an error occured please try again later';
        }
    }
}else{
    $attent = Pasco::create('attendances',$data);
if($attent){
    $url = 'create-attendance.php?attendance_date='.P_Method::input('attendance_date');
    header('location: ../'.$url);
}else{
    echo 'there are an error occured please try again later';
}

}


}
?>