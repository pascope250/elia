<?php
include(__DIR__.'/../controller.php');

if(P_Method::isPost() && empty(P_Method::input('login'))){

        $username = P_Method::input('username');
        $password = md5(P_Method::input('password'));

        $login = Pasco::read('users','*', "username = '$username' AND password = '$password'")->execute();

        if($login != false)
        {
            SessionManager::startSession();
            SessionManager::login($login[0]);
            header('Location: ../index.php');
        }
        else
        {
            echo '<script>alert("Invalid username or password")
            window.location.href="../login.php"</script>';
        }
     
}
?>