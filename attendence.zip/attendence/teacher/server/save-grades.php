<?php
include(__DIR__.'/../controller.php');

if(P_Method::isPost() && !empty(P_Method::input('stid'))){
    $data = [
        'student_id' => P_Method::input('stid'),
        'course_id' => P_Method::input('course_id'),
        'grades' => P_Method::input('grades')
    ];
    $save = Pasco::create('grades', $data);
    if($save != false){
        echo '<script>alert("Data saved successfully")
        window.location.href = "../grades.php";
        </script>';
    }else{
        echo '<script>alert("Data not saved")
        window.location.href = "../grades.php";
        </script>';
    }
}

if(P_Method::input('delete_grade')){
    $id = P_Method::input('delete_grade');
    $delete = Pasco::delete('grades', "grade_id = '$id'");
    if($delete != false){
        echo '<script>alert("Data deleted successfully")
        window.location.href = "../grades.php";
        </script>';
    }else{
        echo '<script>alert("Data not deleted")
        window.location.href = "../grades.php";
        </script>';
    }

}
?>