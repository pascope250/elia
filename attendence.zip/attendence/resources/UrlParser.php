<?php
// use namespace

class UrlParser
{
    /**
     * Get the protocol of the current URL (e.g., "http" or "https").
     *
     * @return string
     */
    public static function getProtocol()
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        return $protocol;
    }

    /**
     * Get the host of the current URL (e.g., "www.example.com").
     *
     * @return string
     */
    public static function getHost()
    {
        return $_SERVER['HTTP_HOST'];
    }

    /**
     * Get the port of the current URL.
     *
     * @return int
     */
    public static function getPort()
    {
        return (int)$_SERVER['SERVER_PORT'];
    }

    /**
     * Get the path of the current URL.
     *
     * @return string
     */
    public static function getPath()
    {
        return $_SERVER['REQUEST_URI'];
    }

    /**
     * Get the query string of the current URL.
     *
     * @return string
     */
    public static function getQueryString()
    {
        return isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
    }

    /**
     * Get the fragment (or anchor) of the current URL.
     *
     * @return string
     */
    public static function getFragment()
    {
        // get fragment of current url
        
        return '';
    }

    // get the current url
    public static function getCurrentUrl()
    {
        $protocol = self::getProtocol();
        $host = self::getHost();
        $port = self::getPort();
        $path = self::getPath();
        $queryString = self::getQueryString();
        $fragment = self::getFragment();

        $url = $protocol . '://' . $host;
        if (($protocol === 'http' && $port != 80) || ($protocol === 'https' && $port != 443)) {
            $url .= ':' . $port;
        }
        $url .= $path;
        if (!empty($queryString)) {
            $url .= '?' . $queryString;
        }
        if (!empty($fragment)) {
            $url .= '#' . $fragment;
        }

        return $url;
    }

   public static function generateFileUrl($filePath)
   {
       $protocol = self::getProtocol();
       $host = self::getHost();
       $port = self::getPort();
       $baseurl = $protocol . '://' . $host;

       if (($protocol === 'http' && $port != 80) || ($protocol === 'https' && $port != 443)) {
           $baseurl .= ':' . $port;
       }

       $fileUrl = rtrim($baseurl, '/') . '/' . ltrim($filePath, '/');

       return $fileUrl;
   }

   // ... (other functions)

   /**
    * Get the current URL without the folder part.
    *
    */
    public static function getCurrentUrlWithoutFolder()
    {
        $url = self::getCurrentUrl();
        $urlParts = parse_url($url);
    
        // Remove the last segment
        $pathSegments = explode('/', trim($urlParts['path'], '/'));
        array_pop($pathSegments);
    
        // Rebuild the URL
        $urlWithoutFolder = $urlParts['scheme'] . '://' . $urlParts['host'] . '/' . implode('/', $pathSegments);
    
        return $urlWithoutFolder;
    }
    
    
}
class P_Method
{
    // if method is files
    public static function isFiles()
{
    return $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES);
}

// if file is empty or null

public static function isFileEmpty($key)
{
    return empty($_FILES[$key]['name']);
}

// get file
public static function getFile($key)

{
    return $_FILES[$key];
}

     /**
     * Check if the current request is a GET request.
     *
     * @return bool
     */
    public static function isGet()
    {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }

    /**
     * Check if the current request is a POST request.
     *
     * @return bool
     */
    public static function isPost()
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }

    /**
     * Check if the specified key exists in the $_REQUEST array.
     *
     * @param string $key The key to check.
     * @return bool
     */
    public static function ifHas($key)
    {
        return isset($_REQUEST[$key]);
    }

    /**
     * Check if the current request is a PUT request.
     *
     * @return bool
     */
    public static function isPut()
    {
        return $_SERVER['REQUEST_METHOD'] === 'PUT';
    }

    /**
     * Get data from the request body for a PUT request.
     *
     * @return array|null Parsed JSON data or null on failure.
     */
    public static function getPutData()
    {
        if (self::isPut()) {
            $putData = file_get_contents('php://input');
            return json_decode($putData, true);
        }
        return null;
    }

    public static function input($key)
    {
        if (isset($_GET[$key])) {
            return $_GET[$key];
        } elseif (isset($_POST[$key])) {
            return $_POST[$key];
        } else {
            return null;
        }
    }
}

// Example usage
// if (P_Method::isPut()) {
//     $putData = P_Method::getPutData();
//     if ($putData !== null) {
//         // Handle the PUT request data
//         var_dump($putData);
//     } else {
//         // Unable to parse JSON from the request body
//         echo 'Invalid JSON data in PUT request.';
//     }
// }

class CacheControl {
    public static function setHeaders() {
        $lastModifiedTimestamp = time();

        // Set cache control headers
        header("Cache-Control: no-cache, must-revalidate");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // A date in the past

        // Set ETag for cache validation
        $etag = md5($lastModifiedTimestamp); // You may need to adjust this based on your content
        header("ETag: \"$etag\"");

        // Check if the client has the same ETag, return 304 Not Modified if true
        if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH'], '"') === $etag) {
            header("HTTP/1.1 304 Not Modified");
            exit;
        }

        // Set Last-Modified header
        header("Last-Modified: " . gmdate("D, d M Y H:i:s", $lastModifiedTimestamp) . " GMT");
    }
// Example usage
// CacheControl::setHeaders();
}


// ?>
