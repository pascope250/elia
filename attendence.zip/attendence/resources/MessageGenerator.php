<?php
class MessageGenerator
{
    /**
     * Generate a success message.
     *
     * @param string $message The success message.
     * @param string $displayStyle The display style for the success message (e.g., 'toastr', 'alert', 'custom').
     * @return string HTML markup for a success message.
     */
    public static function success($message, $displayStyle = 'alert', $value = null)
    {
        $messageHtml = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

         return json_encode(['status' => 'success', 'message' => $messageHtml, 'type' => $displayStyle,'value'=> $value]);

    }

    /**
     * Generate an error message.
     *
     * @param string $message The error message.
     * @param string $displayStyle The display style for the error message (e.g., 'toastr', 'alert', 'custom').
     * @return string HTML markup for an error message.
     */
    public static function error($message, $displayStyle = 'alert',$id="alert-message2")
    {
        $messageHtml = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
      return json_encode(['status' => 'error', 'message' => $messageHtml, 'type' => $displayStyle, 'id' => $id]);

    }

    /**
     * Redirect to a specified URL.
     *
     * @param string $url The URL to redirect to.
     */
    public static function redirect($location, $displayStyle = 'redirect')
    {
        return json_encode(['status' => 'success', 'url' => $location, 'type' => $displayStyle]);
        exit();
    }

    public static function redirect_in_dash($location, $displayStyle = 'dashboard', $modal = false, $message = null)
    {
        return json_encode(['status' => 'success', 'url' => $location, 'type' => $displayStyle, 'modal'=> $modal, 'message' => $message]);
        exit();
    }

    // redirect by using javascript

    public static function redirect_js($location)
    {
        // by <script> tag

        return '<script>window.location.href = "'.$location.'";</script>';
        exit();
    }

    
}

// Example usage:
// Display success message using toastr
// echo MessageGenerator::success('Operation successful!', 'toastr');

// Display error message using a custom style
// echo MessageGenerator::error('Error occurred!', 'custom');

// Redirect to a specified URL
// MessageGenerator::redirect('/home');
?>

