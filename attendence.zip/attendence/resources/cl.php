<?php
class Pasco_Url
{
    const BASE_PATH = '/SACO/';
    const TYPE_SECURE = 'secure';

    public static function prot()
    {
        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $protocol = (defined('type') && constant('type') == self::TYPE_SECURE) ? 'https://' : $protocol; // Use the constant
        return $protocol;
    }


    public static function get_url_host()
    {
        $protocol = self::prot();
        $url_host = $protocol . $_SERVER['HTTP_HOST'] . rtrim(self::BASE_PATH, '/'); // Use the constant
        return $url_host;
    }


    public static function get_url_min()
    {
        $url_query = $_SERVER['QUERY_STRING'];
        return "?" . $url_query;
    }
    public static function get_url_full()
    {
        $protocol = $protocol = self::prot();
        $url_full = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        return $url_full;
    }
    public static function get_url_part()
    {
        $url_all = self::get_url_full();
        $mini = self::get_url_min();
        $ret = str_ireplace($mini, "", $url_all);
        return rtrim(ltrim($ret, "/"), "/");
    }
    public static function without_get()
    {
        $full = self::get_url_full();
        $min = self::get_url_min();
        $ret = str_ireplace($min, "", $full);
        return $ret;
    }
    public static function StaticLink($link)
    {
        $ref = self::get_url_host();
        $fer = $ref . "/" . $link;
        return $fer;
    }
    //get the current page from $url
    public static function get_current_page($url)
    {
        $url = explode('/', $url);
        $url = end($url);
        return $url;
    }
}
