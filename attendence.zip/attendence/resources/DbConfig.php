<?php

class DbConfig
{
    private static $servername = 'localhost';
    private static $username = 'root';
    private static $password = '';
    private static $dbname = 'school_attendance';

    public static function getServername()
    {
        return self::$servername;
    }

    public static function getUsername()
    {
        return self::$username;
    }

    public static function getPassword()
    {
        return self::$password;
    }

    public static function getDbname()
    {
        return self::$dbname;
    }
}

?>
