<?php
$directory = __DIR__;
$files = glob($directory . '/*.php');

foreach ($files as $file) {
    include_once $file;
}

?>
