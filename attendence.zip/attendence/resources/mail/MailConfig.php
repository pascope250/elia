<?php
class MailConfig
{
    public static function getHost()
    {
        return 'smtp.gmail.com';
    }

    public static function getPort()
    {
        return 465;
    }

    public static function getFromAddress()
    {
        return 'cyberconnectrwanda@gmail.com';
    }

    public static function getFromName()
    {
        return 'pas';
    }

    public static function getUsername()
    {
        return 'cyberconnectrwanda@gmail.com';
    }

    public static function getPassword()
    {
        return 'hvsgozkqovconspv';
    }

    public static function appName()
    {
        return 'Cyber Connect Rwanda';
    }


    public static function getEncryption()
    {
        return 'tls';
    }

    public static function getAuth()
    {
        return true;
    }
}
?>