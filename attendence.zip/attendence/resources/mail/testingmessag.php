<?php

$tem_pass = rand(111111,999999);

echo '<center>
    <div class="verify" style="width: 30%; background-color: skyblue; border-radius: 5px;"><br>
         <center><img src="../2/images-removebg-preview.png" alt="" srcset="" style="height: 100px; border: 1px solid whitesmoke;" ></center>
        <h2 style="padding: 10px;">This is Your Verification Code</h2>
       
        
        <p style="font-size: 25px;">Please Enter those verification code below</p>
        <center><p><U style="font-size: 20px;"> CODE:</U><h1>'.$tem_pass.'</h1></P></center> 
            <hr>
            <p style="padding: 20px;">All &copy;CopyRightReserved 2022 pascope250@gmail.com</p>
    </div>
</center>';

?>