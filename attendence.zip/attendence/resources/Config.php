<?php
include 'DbConfig.php';

class Pasco
{
    private $table;
    private $columns;
    private $where;
    private $groupBy;
    private $joins;
    private $orderBy;
    private $limit;
    private static $instance;

    private function __construct() {}
    private static $db = null;

    private static function connect()
    {
        if (self::$db === null) {
            $dsn = "mysql:host=" . DbConfig::getServername() . ";dbname=" . DbConfig::getDbname();

            try {
                self::$db = new \PDO($dsn, DbConfig::getUsername(), DbConfig::getPassword());
                self::$db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            } catch (\PDOException $e) {
                die("Connection failed: " . $e->getMessage());
            }
        }
    }

    // CRUD operations

    public static function create($table, $data)
{
    self::connect();

    $columns = implode(', ', array_keys($data));
    $placeholders = implode(', ', array_fill(0, count($data), '?'));

    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";

    try {
        $stmt = self::$db->prepare($sql);
        $stmt->execute(array_values($data));
        return true;
    } catch (PDOException $e) {
        // Output or log the actual error message
        echo 'Error: ' . $e->getMessage();
        return false;
    }
}

public static function read($tables, $columns = '*', $where = null, $joins = null, $groupBy = null) {
    self::$instance = new self();
    self::$instance->table = $tables;
    self::$instance->columns = $columns;
    self::$instance->where = $where;
    self::$instance->joins = $joins;
    self::$instance->groupBy = $groupBy;
    return self::$instance;
}

    public function orderBy($orderBy) {
        $this->orderBy = $orderBy;
        return $this;
    }

    public function limit($limit) {
        $this->limit = $limit;
        return $this;
    }

    public function groupBy($groupBy) {
        $this->groupBy = $groupBy;
        return $this;
    }
    public function join($joins) {
        $this->joins = $joins;
        return $this;
    }


    public function execute() {
        self::connect();
    
        $sql = "SELECT {$this->columns} FROM {$this->table}";
    
        if ($this->joins) {
            $sql .= " " . implode(" ", $this->joins);
        }
    
        if ($this->where) {
            $sql .= " WHERE {$this->where}";
        }
    
        if ($this->groupBy) {
            $sql .= " GROUP BY {$this->groupBy}";
        }
    
        if ($this->orderBy) {
            $sql .= " ORDER BY {$this->orderBy}";
        }

        if ($this->limit) {
            $sql .= " LIMIT {$this->limit}";
        }
    
        try {
            $stmt = self::$db->query($sql);
            if ($stmt === false) {
                // Handle query execution error
                $errorInfo = self::$db->errorInfo();
                throw new Exception("Query execution error: " . $errorInfo[2]);
            }
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle PDO exception
            return false;
        } catch (Exception $e) {
            // Handle other exceptions
            return false;
        }
    }
    




    public static function readLimit($table, $columns = '*', $where = null, $limit = 10)
    {
        self::connect();

        $sql = "SELECT $columns FROM $table";
        if ($where) {
            $sql .= " WHERE $where";
        }

        // Add LIMIT clause
        $sql .= " LIMIT $limit";

        try {
            $stmt = self::$db->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    // read by selecting unique records

    public static function readUnique($table, $unique, $columns = '*', $where = null)
    {
        self::connect();

        $sql = "SELECT DISTINCT $unique, $columns FROM $table";
        if ($where) {
            $sql .= " WHERE $where";
        }

        try {
            $stmt = self::$db->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    // Find a single row

    public static function find($table, $where)
    {
        self::connect();

        $sql = "SELECT * FROM $table WHERE $where LIMIT 1";

        try {
            $stmt = self::$db->query($sql);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    public static function update($table, $data, $where = null)
    {
        self::connect();

        $set = implode(', ', array_map(function ($key) {
            return "$key=?";
        }, array_keys($data)));

        $sql = "UPDATE $table SET $set WHERE $where";

        try {
            $stmt = self::$db->prepare($sql);
            $stmt->execute(array_values($data));
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public static function delete($table, $where)
    {
        self::connect();

        $sql = "DELETE FROM $table WHERE $where";

        try {
            $stmt = self::$db->prepare($sql);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    // Aggregations and Joins

    public static function countRows($table, $where = null)
    {
        self::connect();

        $sql = "SELECT COUNT(*) FROM $table";
        if ($where) {
            $sql .= " WHERE $where";
        }

        $stmt = self::$db->query($sql);
        $count = $stmt->fetchColumn();
        return $count;
    }

    public static function innerJoin($table1, $table2, $condition)
    {
        self::connect();

        $sql = "SELECT * FROM $table1 INNER JOIN $table2 ON $condition";

        try {
            $stmt = self::$db->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    // Data existence check

    public static function checkIfExists($table, $conditions)
    {
        self::connect();

        $sql = "SELECT COUNT(*) FROM $table WHERE $conditions";
        $stmt = self::$db->prepare($sql);
        $stmt->execute();

        if ($stmt) {
            $count = $stmt->fetchColumn();
            return ($count > 0);
        }
        return false;
    }

    public static function checkEmailExistsExcept($table, $columnName, $columnValue, $excludeColumnName, $excludeColumnValue)
    {
        self::connect();
    
        $sql = "SELECT COUNT(*) FROM $table WHERE $columnName = :columnValue AND $excludeColumnName != :excludeColumnValue";
        $stmt = self::$db->prepare($sql);
        $stmt->bindParam(':columnValue', $columnValue);
    
        // Assuming exclude column value is an integer, adjust the parameter type if needed
        $stmt->bindParam(':excludeColumnValue', $excludeColumnValue, PDO::PARAM_INT);
    
        $stmt->execute();
    
        if ($stmt) {
            $count = $stmt->fetchColumn();
            return ($count > 0);
        }
    
        return false;
    }
    


    // Foreign key operations

    public static function enableForeignKeyChecks()
    {
        self::connect();
        self::$db->exec('SET foreign_key_checks = 1');
    }

    public static function disableForeignKeyChecks()
    {
        self::connect();
        self::$db->exec('SET foreign_key_checks = 0');
    }



    // make pagination with link of previous and next page

    /**
     * Generate HTML for pagination links.
     *
     * @param int $currentPage The current page number.
     * @param int $limit The number of records per page.
     * @param int $totalRecords The total number of records.
     * @param string $urlTemplate The URL template for pagination links. Use {page} as a placeholder for the page number.
     * @return string The HTML for pagination links.
     */
    public static function generatePagination($table, $currentPage, $limit, $urlTemplate, $conditions = null)
    {
        $totalRecords = self::countRows($table, $conditions);
        $totalPages = ceil($totalRecords / $limit);
        $paginationHtml = '<ul class="pagination">';

        // Previous page link
        if ($currentPage > 1) {
            $prevPage = $currentPage - 1;
            $prevLink = str_replace('{page}', $prevPage, $urlTemplate);
            $paginationHtml .= '<li class="page-item"><a class="page-link pagination-link" href="' . htmlspecialchars($prevLink, ENT_QUOTES, 'UTF-8') . '">Previous</a></li>';
        }

        // Page links
        for ($i = 1; $i <= $totalPages; $i++) {
            $pageLink = str_replace('{page}', $i, $urlTemplate);
            $activeClass = ($i == $currentPage) ? 'active' : '';
            $paginationHtml .= '<li class="page-item ' . $activeClass . '"><a class="page-link pagination-link" href="' . htmlspecialchars($pageLink, ENT_QUOTES, 'UTF-8') . '">' . $i . '</a></li>';
        }

        // Next page link
        if ($currentPage < $totalPages) {
            $nextPage = $currentPage + 1;
            $nextLink = str_replace('{page}', $nextPage, $urlTemplate);
            $paginationHtml .= '<li class="page-item"><a class="page-link pagination-link" href="' . htmlspecialchars($nextLink, ENT_QUOTES, 'UTF-8') . '">Next</a></li>';
        }

        $paginationHtml .= '</ul>';

        return $paginationHtml;
    }

//     // Assuming you want to display 10 records per page
// $limit = 10;

// // Assuming you are on page 2
// $currentPage = 2;

// // Get the total number of records in the "example_table"
// $totalRecords = Operations::getTotalRecords('example_table');

// // Generate pagination HTML
// $urlTemplate = 'example.php?page={page}';
// $paginationHtml = Operations::generatePagination($currentPage, $limit, $totalRecords, $urlTemplate);

// // Output the result
// echo $paginationHtml;

// // Fetch records for the current page
// $records = Operations::readLimit('example_table', '*', null, $limit, $currentPage);
// print_r($records);
}

?>