<?php
define('APP_NAME', 'ATTENDANCE SYSTEM');
define('PROGRAMMER_EMAIL', 'dev.pascope250@gmail.com');
define('PROGRAMMER_NAME', 'Celestin NDAYAMBAJE');
define('PROGRAMMER_PHONE', '+250 781 495 385');
define('PROGRAMMER_ADDRESS', 'kigali, rwanda');
define('PROGRAMMER_WEBSITE', 'https://www.pascope250.com');
define('PROGRAMMER_WEBSITE_NAME', 'pascope250.com');
define('PROGRAMMER_WEBSITE_DESCRIPTION', 'deleloper of webApplications');
define('SECURITY_KEY', '%$*nc)(*#!@#$%^&[bY97');
define('CROSS_URL_KEY', '>>>>>>+%%%%>>..*(&@#$%sJfs-=``4');
define('type', 'secure');
define('BASE_PATH', '/urugendo');
define('APP_URL', 'https://localhost/urugendo');
define('TYPE_SECURE', 'secure');

class pageTitle {
    public static function title($title) {
        return $title . ' | ' . APP_NAME;
    }
}