<?php

class SessionManager
{
    /**
     * Start the session.
     */
    public static function startSession()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }
    /**
     * Log in a user.
     *
     * @param array $userDetails User details including username, role, etc.
     * @return bool True if login is successful, false otherwise.
     */
    public static function login(array $userDetails)
    {
        self::startSession();

        // Check if the user is already logged in
        if (isset($_SESSION['user'])) {
            return false; // User is already logged in
        }

        // Set user details in the session
        $_SESSION['user'] = $userDetails;

        return true;
    }

    /**
     * Log out the current user.
     */
    public static function logout()
    {
        self::startSession();

        // Unset user details
        unset($_SESSION['user']);

        // Destroy the session
        session_destroy();
    }
    /**
     * Get the current user's details.
     *
     * @return array|null User details if logged in, null otherwise.
     */
    public static function getUser()
    {
        self::startSession();

        return isset($_SESSION['user']) ? $_SESSION['user'] : null;
    }

    /**
     * Check if the user is logged in.
     *
     * @return bool True if the user is logged in, false otherwise.
     */
    public static function isLoggedIn()
    {
        self::startSession();

        return isset($_SESSION['user']);
    }

    /**
     * Check if the current user has a specific role.
     *
     * @param string $role The role to check.
     * @return bool True if the user has the specified role, false otherwise.
     */
    public static function hasRole($role)
    {
        self::startSession();

        return isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === $role;
    }
}
?>