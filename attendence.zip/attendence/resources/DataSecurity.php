<?php
class DataSecurity
{
    public static function validatePassword($password)
    {
        // Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character
        return (bool) preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
    }
    public static function hashPassword($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    public static function verifyPassword($password, $hashedPassword)
    {
        return password_verify($password, $hashedPassword);
    }

    // password matching
    public static function passwordMatch($pass1, $pass2)
    {
        if ($pass1 === $pass2) {
            return true;
        } else {
            return false;
        }
    }

    // make function for auto generate password containing number and letter

    public static function generatePassword()
    {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        return $password;
    }


    public static function isEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function isWebsite($url)
    {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }

    public static function isNumber($value)
    {
        return is_numeric($value);
    }
}



class CsrfProtection
{
    /**
     * Check if a session exists.
     *
     * @return bool True if a session exists, false otherwise.
     */
    public static function sessionExists()
    {
        return session_status() === PHP_SESSION_ACTIVE;
    }

    /**
     * Generate a random CSRF token, store it in the session, and return it.
     *
     * @return string
     */
    public static function generateToken()
    {
        if (!self::sessionExists()) {
            session_start();
        }

        $token = bin2hex(random_bytes(32)); // Generate a random 32-byte string
        $_SESSION['csrf_token'] = $token;
        return $token;
    }

    /**
     * Verify if the submitted CSRF token matches the one stored in the session.
     *
     * @param string $submittedToken The CSRF token submitted with the request.
     * @return bool True if the token is valid, false otherwise.
     */
    public static function verifyToken($submittedToken)
    {
        if (!self::sessionExists()) {
            session_start();
        }

        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $submittedToken);
    }

    /**
     * Include the CSRF token in the form as a hidden field.
     *
     * @return string The HTML code for the CSRF token hidden field.
     */
    public static function getTokenField()
    {
        $token = self::generateToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }

    /**
     * Generate a random CSRF token for Form 2, store it in the session, and return it.
     *
     * @return string
     */
    public static function generateTokenForm2()
    {
        if (!self::sessionExists()) {
            session_start();
        }

        $token = bin2hex(random_bytes(32)); // Generate a random 32-byte string
        $_SESSION['csrf_token2'] = $token;
        return $token;
    }

    /**
     * Verify if the submitted CSRF token for Form 2 matches the one stored in the session.
     *
     * @param string $submittedToken The CSRF token submitted with the request.
     * @return bool True if the token is valid, false otherwise.
     */
    public static function verifyTokenForm2($submittedToken)
    {
        if (!self::sessionExists()) {
            session_start();
        }

        return isset($_SESSION['csrf_token2']) && hash_equals($_SESSION['csrf_token2'], $submittedToken);
    }

    /**
     * Include the CSRF token for Form 2 in the form as a hidden field.
     *
     * @return string The HTML code for the CSRF token hidden field for Form 2.
     */
    public static function getTokenFieldForm2()
    {
        $token = self::generateTokenForm2();
        return '<input type="hidden" name="csrf_token2" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }

    /**
     * Clear the CSRF token stored in the session.
     */

    public static function clearToken(){
        if (!self::sessionExists()) {
            session_start();
        }
        unset($_SESSION['csrf_token']);
    }
}

// Example usage:
// $csrfToken = CsrfProtection::generateToken();
// $isValidToken = CsrfProtection::verifyToken($submittedToken);
// $csrfTokenField = CsrfProtection::getTokenField();


class EncryptionManager
{
    const AES_KEY_SIZE = 32; // 256 bits for AES-256
    const AES_IV_SIZE = 16; // 128 bits for AES-128

    /**
     * Encrypt data using AES-256-CBC encryption.
     *
     * @param string $data The data to encrypt.
     * @param string $key The encryption key.
     * @return string The encrypted data.
     */
    public static function encrypt($data, $key)
    {
        $iv = random_bytes(self::AES_IV_SIZE); // Generate a random initialization vector
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);

        $combinedData = $iv . $encrypted;
        $base64Encoded = base64_encode($combinedData);

        return urlencode($base64Encoded);
    }

    /**
     * Decrypt data encrypted with AES-256-CBC.
     *
     * @param string $encryptedParam The URL-encoded and base64-encoded encrypted data.
     * @param string $key The decryption key.
     * @return string|false The decrypted data, or false on failure.
     */
    public static function decrypt($encryptedParam, $key)
    {
        $combinedData = base64_decode(urldecode($encryptedParam));
        $iv = substr($combinedData, 0, self::AES_IV_SIZE); // Extract the IV
        $encrypted = substr($combinedData, self::AES_IV_SIZE);

        return openssl_decrypt($encrypted, 'aes-256-cbc', $key, 0, $iv);
    }
}

// Example Usage:

// Encryption
// $plaintext = "This is a secret message.";
// $key = "your_secret_key"; // Replace with your actual secret key
// $encryptedParam = EncryptionManager::encrypt($plaintext, $key);
// echo "Encrypted: $encryptedParam\n";

// // Decryption
// $decryptedText = EncryptionManager::decrypt($encryptedParam, $key);
// echo "Decrypted: $decryptedText\n";


// create uuid for user class
class Uuid
{
    /**
     * Generate a UUID version 4.
     *
     * @return string The UUID.
     */
    public static function generate()
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // Set version to 0100
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // Set bits 6-7 to 10

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    // Generate a random number

    public static function random_number()
    {
        return rand(100000, 999999);
    }

    public static function random_number_time(){
        return self::random_number().(int)time();
    }
}

// class for making email token

class Token
{
    /**
     * Generate a random email verification token.
     *
     * @return string The token.
     */
    public static function generate()
    {
        return bin2hex(random_bytes(50));
    }
}
