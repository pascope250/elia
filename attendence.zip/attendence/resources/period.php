<?php
class Period
{
    public static function calculateTimeDifference($startTime, $endTime)
    {
        $startTimestamp = strtotime($startTime);
        $endTimestamp = strtotime($endTime);

        if ($startTimestamp === false || $endTimestamp === false) {
            return false; // Invalid timestamps
        }

        $difference = abs($endTimestamp - $startTimestamp);

        return $difference;
    }
    

    public static function formatDateTime($timestamp, $format = 'Y-m-d H:i:s')
    {
        return date($format, strtotime($timestamp));
    }

    public static function formatTime($timestamp, $format = 'H:i:s')
    {
        return date($format, strtotime($timestamp));
    }

    public static function formatDate($timestamp, $format = 'Y-m-d')
    {
        return date($format, strtotime($timestamp));
    }

    public static function getRemainingPeriod($timestamp)
    {
        $currentTimestamp = time();
        $timestamp = strtotime($timestamp);

        if ($timestamp === false) {
            return false; // Invalid timestamp
        }

        $difference = $currentTimestamp - $timestamp;

        if ($difference < 60) {
            return $difference . ' seconds ago';
        } elseif ($difference < 3600) {
            $minutes = floor($difference / 60);
            return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
        } elseif ($difference < 86400) {
            $hours = floor($difference / 3600);
            return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } elseif ($difference < 2592000) {
            $days = floor($difference / 86400);
            return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
        } else {
            return self::formatDateTime($timestamp);
        }
    }

    public static function currentYear(){
        return date('Y');
    }

    public static function isTimeExpired($timestamp)
    {
        $currentTimestamp = time();
        $timestamp = strtotime($timestamp);

        if ($timestamp === false) {
            return false; // Invalid timestamp
        }

        return $currentTimestamp > $timestamp;
    }

    public static function addTime($amount, $unit = 'year')
    {
        $currentTimestamp = time();
        
        // Determine whether to add or subtract based on the sign of $amount
        $operation = ($amount >= 0) ? '+' : '-';
        
        $newTimestamp = strtotime($operation . abs($amount) . ' ' . $unit, $currentTimestamp);
    
        if ($newTimestamp === false) {
            return false; // Invalid duration
        }
    
        return date('Y-m-d H:i:s', $newTimestamp);
    }
    

    public static function subtractTime($amount, $unit)
{
    $currentTimestamp = time();
    $newTimestamp = strtotime("-" . $amount . " " . $unit, $currentTimestamp);

    if ($newTimestamp === false) {
        return false; // Invalid duration
    }

    return date('Y-m-d H:i:s', $newTimestamp);
}

}

class Timer {

    public static function getRemainingTime($addtime) {
        // Set the time zone to Kigali
        $timezone = new DateTimeZone('Africa/Kigali');
    
        // Set the deadline for the event with the specified time zone
        $deadline = new DateTime($addtime, $timezone);
    
        // Get the current time with the specified time zone
        $now = new DateTime('now', $timezone);
    
        // Calculate the time difference
        $interval = $now->diff($deadline);

        
        // if current time is greater than deadline

        if ($now > $deadline) {
            return false;
        }else{
            return array(
            'days' => $interval->d,
            'hours' => $interval->h,
            'minutes' => $interval->i,
            'seconds' => $interval->s
        );
        }
        // Return the remaining time as an associative array
        
    }
    
}


class DateTimeFormatter {
    public static function formatDateTime($dateTimeString) {
        $formattedDateTime = strtotime($dateTimeString);
        $formattedDateTime = date('Y F d g:i:s A', $formattedDateTime);
        return $formattedDateTime;
    }


}