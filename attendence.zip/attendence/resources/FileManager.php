<?php
// Include the library
// require_once('qr/qrlib.php');

class FileManager
{
    private $baseDirectory;
    private $allowedImageTypes = ['jpg', 'jpeg', 'png', 'gif'];
    // all document types
    private $allowedDocumentTypes = ['pdf', 'doc', 'docx', 'txt', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'rtf'];

    public function __construct($baseDirectory)
    {
        // Make the base directory relative to the current script using __DIR__
        $this->baseDirectory = rtrim(__DIR__ . '/' . $baseDirectory, '/') . '/';
    }

    public function fileExists($filename)
    {
        $filePath = $this->buildFilePath($filename);
        return file_exists($filePath);
    }

    // delete file from directory
    public function deleteFile($filename)
    {
        $filePath = $this->buildFilePath($filename);
        if (file_exists($filePath)) {
            unlink($filePath);
            return true;
        }
        return false;
    }

    public function getFullFileLink($filename)
    {
        if ($this->fileExists($filename)) {
            return $this->getBaseUrl() . $this->buildFilePath($filename);
        }
        return false;
    }

    public function uploadSingleImage($file)
    {
        return $this->uploadFile($file, $this->allowedImageTypes);
    }

    public function uploadSingleImageWithConversion($file, $maxWidth, $maxHeight, $outputType = 'jpg', $quality = 75)
    {
        $uploadedFile = $this->uploadFile($file, $this->allowedImageTypes);
        if ($uploadedFile !== false) {
            // get only the file name file:///C:/xampp/htdocs/saco/uploads/properties/WhatsApp%20Image%202024-04-16%20at%2016.07.18_b39eb4bd_663df35328814.jpg
            $convertedImage = $this->convertImage($uploadedFile, $maxWidth, $maxHeight, $outputType, $quality);

            // delete $uploadedFile
            $this->deleteFile($uploadedFile);
            return $convertedImage;
            
        }
        return false;
    }

    public function uploadMultipleImages($file)
    {
        return $this->uploadFiles($file, $this->allowedImageTypes);
    }

    public function uploadMultipleImagesWithConversion($file, $maxWidth, $maxHeight, $outputType = 'jpg', $quality = 75)
    {
        $uploadedFiles = $this->uploadFiles($file, $this->allowedImageTypes);
        $convertedImages = [];
        foreach ($uploadedFiles as $uploadedFile) {
            $convertedImage = $this->convertImage($uploadedFile, $maxWidth, $maxHeight, $outputType, $quality);
            if ($convertedImage !== false) {
                $convertedImages[] = $convertedImage;
            }
        }
        return $convertedImages;
    }

    public function uploadDocument($file)
    {
        return $this->uploadFile($file, $this->allowedDocumentTypes);
    }

    private function buildFilePath($filename)
    {
        return $this->baseDirectory . $filename;
    }

    private function getBaseUrl()
    {
        $protocol = UrlParser::getProtocol();
        $host = UrlParser::getHost();
        $port = UrlParser::getPort();

        $baseUrl = $protocol . '://' . $host;
        if (($protocol === 'http' && $port != 80) || ($protocol === 'https' && $port != 443)) {
            $baseUrl .= ':' . $port;
        }

        return $baseUrl;
    }

    private function uploadFile($file, $allowedTypes)
    {
        if (isset($file)) {
            // Validate file type
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (!in_array(strtolower($fileExtension), $allowedTypes)) {
                return false; // Invalid file type
            }

            // Validate file size (adjust as needed)
            $maxFileSize = 100 * 1024 * 1024;// 5 MB
            if ($file['size'] > $maxFileSize) {
                return false; // File size exceeds the limit
            }

            // Move the uploaded file to the destination
            $destinationDirectory = $this->baseDirectory;
            if (!file_exists($destinationDirectory)) {
                mkdir($destinationDirectory, 0755, true);
            }

            $filename = $this->generateUniqueFilename($file['name']);
            $destinationPath = $this->buildFilePath($filename);

            if (move_uploaded_file($file['tmp_name'], $destinationPath)) {
                return $filename; // Successful upload
            }
        }

        return false; // Upload failed
    }

    private function uploadFiles($file, $allowedTypes)
    {
        $uploadedFiles = [];

        if (isset($file['tmp_name']) && is_array($file['tmp_name'])) {
            foreach ($file['tmp_name'] as $index => $tmpName) {
                $uploadedFile = $this->uploadFile([
                    'name' => $file['name'][$index],
                    'type' => $file['type'][$index],
                    'tmp_name' => $tmpName,
                    'error' => $file['error'][$index],
                    'size' => $file['size'][$index],
                ], $allowedTypes);
                if ($uploadedFile !== false) {
                    $uploadedFiles[] = $uploadedFile;
                }
            }
        }

        return $uploadedFiles;
    }

    private function convertImage($filename, $maxWidth, $maxHeight, $outputType, $quality)
    {
        $inputPath = $this->buildFilePath($filename);

        list($width, $height, $type) = getimagesize($inputPath);

        $aspectRatio = $width / $height;

        if ($width > $maxWidth || $height > $maxHeight) {
            if ($aspectRatio > 1) {
                $newWidth = $maxWidth;
                $newHeight = $maxWidth / $aspectRatio;
            } else {
                $newWidth = $maxHeight * $aspectRatio;
                $newHeight = $maxHeight;
            }

            $imageResized = imagecreatetruecolor($newWidth, $newHeight);

            switch ($type) {
                case IMAGETYPE_JPEG:
                    $imageSource = imagecreatefromjpeg($inputPath);
                    imagecopyresampled($imageResized, $imageSource, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    $convertedImagePath = $this->buildFilePath('saco' . $filename);
                    imagejpeg($imageResized, $convertedImagePath, $quality);
                    imagedestroy($imageResized);
                    return $convertedImagePath;
                case IMAGETYPE_PNG:
                    $imageSource = imagecreatefrompng($inputPath);
                    imagecopyresampled($imageResized, $imageSource, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    $convertedImagePath = $this->buildFilePath('saco' . $filename);
                    imagepng($imageResized, $convertedImagePath);
                    imagedestroy($imageResized);
                    return $convertedImagePath;
                case IMAGETYPE_GIF:
                    $imageSource = imagecreatefromgif($inputPath);
                    imagecopyresampled($imageResized, $imageSource, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    $convertedImagePath = $this->buildFilePath('saco' . $filename);
                    imagegif($imageResized, $convertedImagePath);
                    imagedestroy($imageResized);
                    return $convertedImagePath;

                default:
                    return $inputPath;
            }
        }
    }

    private function generateUniqueFilename($filename)
    {
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $filenameWithoutExtension = pathinfo($filename, PATHINFO_FILENAME);
        $uniqueFilename = $filenameWithoutExtension . '_' . uniqid() . '.' . $extension;
        return $uniqueFilename;
    }
    

}



class fileVersioning{
    // function for versioning file name
    public static function generateScriptTag($scriptLink) {
        $timestamp = time(); // Get current timestamp

        // Check if the file extension is already included
        $extension = pathinfo($scriptLink, PATHINFO_EXTENSION);
        $versionedLink = ($extension ? $scriptLink : "{$scriptLink}.js") . "?v={$timestamp}";
        return "<script src=\"{$versionedLink}\"></script>";
    }

// // Usage example
// $customScriptLink = "https://example.com/my-script";
// $scriptTag = ScriptGenerator::generateScriptTag($customScriptLink);
// echo $scriptTag;


public static function generateStyleTag($styleLink) {
    $timestamp = time(); // Get current timestamp
    $versionedLink = "{$styleLink}?v={$timestamp}";

    return "<link rel=\"stylesheet\" href=\"{$versionedLink}\">";
}

// Usage example
// $customStyleLink = "https://example.com/style.css";
// $styleTag = StyleGenerator::generateStyleTag($customStyleLink);
// echo $styleTag;
}



class QRCodeGenerator {
    
    public static function generateQRCode($data, $filename, $size = 200, $errorCorrectionLevel = 'L', $margin = 4) {
        // Set up QR code configuration
        $qrConfig = [
            'data' => $data,
            'filename' => $filename,
            'size' => $size,
            'level' => $errorCorrectionLevel,
            'margin' => $margin,
        ];
        
        // Generate QR code
        QRcode::png($qrConfig['data'], $qrConfig['filename'], $qrConfig['level'], $qrConfig['size'], $qrConfig['margin']);
        
        // Output the generated QR code
        // echo '<img src="' . $qrConfig['filename'] . '" />';
    }
}

// Example usage:
// $data = "Hello, World!";
// $filename = "qrcode.png";
// QRCodeGenerator::generateQRCode($data, $filename);

?>
